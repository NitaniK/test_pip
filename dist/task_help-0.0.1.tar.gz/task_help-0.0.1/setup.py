from setuptools import setup
setup(name="task_help",
      author="nitani",
      author_email="e1c20074@oit.ac.jp",
      maintainer="nitani",
      maintainer_email="e1c20074@oit.ac.jp",
      description="help me",
      long_description="aaa",
      license="a",
      url="https://github.com/NitaniK/test_pip.git",
      version="0.0.1",
      download_url="https://github.com/NitaniK/test_pip.git",
      python_requires="",
      install_requires=["numpy>=1.12"],
      extras_require={},
      packages="",
      classifiers=""
    )